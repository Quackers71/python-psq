from distutils.core import setup


setup(
    name='palindrome',
    version='1.0',
    py_modules=['palindrome'],

    # metadata
    author='Quackers',
    author_email='q@quacks.com',
    description='A module for finding palidrome numbers.',
    licence='Public domain',
    keywords='example',
)
